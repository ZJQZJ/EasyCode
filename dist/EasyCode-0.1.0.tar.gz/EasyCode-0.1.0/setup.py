from setuptools import setup, find_packages
setup(
    name='EasyCode',
    version = "0.1.0",
    keywords=("Easy", "Coding"),
    description="a Easy package for code",
    long_description="a Easy package for code",
    license="MIT Licence",
    url="https://github.com/fengmm521/pipProject",
    author="mage",
    author_email="zjqzjq20091026@163.com",
    packages=find_packages(),
    include_package_data=True,
    platforms="any",
    install_requires=[]
)